Run Terminal Command Here
===

![Run Terminal Command Here Screenshot](http://github.com/franzheidl/alfred-workflows/raw/master/screenshots/cdh_git-status.png)

Use Keyword "cdh" to cd into your currently open Finder directory. 

To run a Terminal Command , use "cdh [your command]".

If there is no folder currently open in Finder, your command will be run in your Desktop folder.

The workflow will by default execute your command in the first non-busy Terminal window it finds, otherwise open a new one. To explicitly run the command in a new Terminal window, press [alt] when firing your command in Alfred 2.